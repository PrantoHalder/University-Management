﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace University_application
{
    /// <summary>
    /// Interaction logic for ins.xaml
    /// </summary>
    public partial class ins : Window
    {
        public ins()
        {
            InitializeComponent();
        }

        private void Dept_instructor1_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult mr = MessageBox.Show("do you really want to log out?", "Log out confirmation", MessageBoxButton.YesNo, MessageBoxImage.Warning, MessageBoxResult.Yes);
            switch (mr)
            {
                case MessageBoxResult.Yes:

                    break;
                case MessageBoxResult.No:
                    break;
                default:
                    break;
            }

            log_in ni = new log_in();
            ni.Show();
            this.Close();

        }

        private void Ins_instructor_Click(object sender, RoutedEventArgs e)
        {
           
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            up_ins ni = new up_ins();
            ni.Show();
            this.Close();

        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
             Update_ins ni = new Update_ins();
            ni.Show();
            this.Close();
        }

        private void MenuItem_Click_2(object sender, RoutedEventArgs e)
        {
            new_ins ni = new new_ins();
            ni.Show();
            this.Close();
        }

        private void MenuItem_Click_3(object sender, RoutedEventArgs e)
        {
            newStudent ns = new newStudent();
            ns.Show();
            this.Close();
        }

        private void MenuItem_Click_4(object sender, RoutedEventArgs e)
        {
            new_stu_search ni = new new_stu_search();
            ni.Show();
            this.Close();
        }

        private void MenuItem_Click_5(object sender, RoutedEventArgs e)
        {
            delete_Ins ni = new delete_Ins();
            ni.Show();
            this.Close();
        }

        private void MenuItem_Click_6(object sender, RoutedEventArgs e)
        {
            delete_stu ni = new delete_stu();
            ni.Show();
            this.Close();
        }

        private void MenuItem_Click_7(object sender, RoutedEventArgs e)
        {
            update_stu ni = new update_stu();
            ni.Show();
            this.Close();
        }

        private void MenuItem_Click_8(object sender, RoutedEventArgs e)
        {
            Data_Over_View_ins ni = new Data_Over_View_ins();
            ni.Show();
            this.Close();
        }

        private void MenuItem_Click_9(object sender, RoutedEventArgs e)
        {
            Data_Over_View_stu ni = new Data_Over_View_stu();
            ni.Show();
            this.Close();
        }
    }
}
