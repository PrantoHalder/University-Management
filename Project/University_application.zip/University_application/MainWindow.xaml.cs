﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace University_application
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            
            MessageBoxResult mr = MessageBox.Show("do you really want to log out?", "Log out confirmation", MessageBoxButton.YesNo, MessageBoxImage.Warning, MessageBoxResult.Yes);
            switch (mr)
            {
                case MessageBoxResult.Yes:
                    System.Environment.Exit(0);

                    break;
                case MessageBoxResult.No:
                    MainWindow ni = new MainWindow();
                    ni.Show();
                    this.Close();
                    break;
                default:
                    break;
            }

            
            
           
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            this.Hide();
            log_in ss = new log_in();
            ss.Show();
            this.Close();
        }
    }
}
