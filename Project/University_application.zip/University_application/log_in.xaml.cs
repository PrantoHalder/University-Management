﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;

namespace University_application
{
    /// <summary>
    /// Interaction logic for log_in.xaml
    /// </summary>
    public partial class log_in : Window
    {
        public log_in()
        {
            InitializeComponent();
        }
        public static string Id;
        public static string recby
        {
            get { return Id;}
            set { Id = value; }
        }


        private void Button_Click(object sender, RoutedEventArgs e)
        {
          
            MessageBoxResult mr = MessageBox.Show("do you really want to log out?", "Log out confirmation", MessageBoxButton.YesNo, MessageBoxImage.Warning);
            switch (mr)
            {
                case MessageBoxResult.Yes:
                    {
                        MainWindow ni = new MainWindow();
                        ni.Show();
                        System.Environment.Exit(0);
                        break;
                    }
                case MessageBoxResult.No:
                    {
                        log_in nii = new log_in();
                        nii.Show();
                        this.Close();
                        break;
                    }
                default:
                    break;
            }


           
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            string connectionstring = @"Data Source=DESKTOP-L8U6JI8;Initial Catalog=University_application;Integrated Security=True";
            SqlConnection sqlcon = new SqlConnection(connectionstring);
            if (c1.IsChecked == true)
            {

                sqlcon.Open();
                string commandstring = "select * from dbo.advisor";
                SqlCommand sqlcmd = new SqlCommand(commandstring, sqlcon);
                SqlDataReader read = sqlcmd.ExecuteReader();


                while (read.Read())
                {

                    if (t1.Text == read[1].ToString() && pf1.Password == read[2].ToString())
                    {
                        ins im = new ins();
                        im.Show();
                        this.Close();
                    }




                }

                sqlcon.Close();

            }
            else if (c4.IsChecked == true)
            {

                string connection = @"Data Source=DESKTOP-L8U6JI8;Initial Catalog=University_application;Integrated Security=True";
                SqlConnection sqlcon3 = new SqlConnection(connection);
                sqlcon3.Open();
                string command1 = "select * from dbo.new_instructor";
                SqlCommand sqlcmd3 = new SqlCommand(command1, sqlcon3);
                SqlDataReader read4 = sqlcmd3.ExecuteReader();



                while (read4.Read())
                {


                    if (t1.Text == read4[2].ToString() && pf1.Password == read4[9].ToString())
                    {
                        recby = t1.Text;
                        advisor ss = new advisor();
                        ss.Show();
                        this.Close();

                    }




                }



                sqlcon3.Close();
            }


            else if (c3.IsChecked == true)
            {

                string connection = @"Data Source=DESKTOP-L8U6JI8;Initial Catalog=University_application;Integrated Security=True";
                SqlConnection sqlcon2 = new SqlConnection(connection);
                sqlcon2.Open();
                string command = "select * from dbo.student_information";
                SqlCommand sqlcmd1 = new SqlCommand(command, sqlcon2);
                SqlDataReader read1 = sqlcmd1.ExecuteReader();



                while (read1.Read())
                {


                    if (t1.Text == read1[2].ToString() && pf1.Password == read1[7].ToString())
                    {
                        recby = t1.Text;
                        Student ss = new Student();
                        ss.Show();
                        this.Close();

                    }




                }



                sqlcon2.Close();
            }

            else

            {
                MessageBox.Show("Please Enter all the Fields", "Wrong Process", MessageBoxButton.OK, MessageBoxImage.Warning);

            }
        }
    }
}
