﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace University_application
{
    /// <summary>
    /// Interaction logic for thanks_new_ins.xaml
    /// </summary>
    public partial class thanks_new_ins : Window
    {
        public thanks_new_ins()
        {
            InitializeComponent();
        }


        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
           
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
         

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult mr = MessageBox.Show("do you really want to log out?", "Log out confirmation", MessageBoxButton.YesNo, MessageBoxImage.Warning, MessageBoxResult.Yes);
            switch (mr)
            {
                case MessageBoxResult.Yes:

                    break;
                case MessageBoxResult.No:
                    break;
                default:
                    break;
            }


            ins ni = new ins();
            ni.Show();
            this.Close();
        }
    }
}
