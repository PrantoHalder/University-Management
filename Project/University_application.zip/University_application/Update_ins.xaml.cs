﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;

namespace University_application
{
    /// <summary>
    /// Interaction logic for Update_ins.xaml
    /// </summary>
    public partial class Update_ins : Window
    {
        public Update_ins()
        {
            InitializeComponent();
        }


        private void Button_Click(object sender, RoutedEventArgs e)
        {
            
            t2.Clear();
            t3.Clear();
            t4.Clear();
            t5.Clear();
            t6.Clear();
            t7.Clear();
            t9.Clear();
            t10.Clear();
            t11.Clear();
            string connectionstring = @"Data Source=DESKTOP-L8U6JI8;Initial Catalog=University_application;Integrated Security=True";
            SqlConnection sqlcon = new SqlConnection(connectionstring);
            sqlcon.Open();
            string commandstring = "select * from dbo.new_instructor";
            SqlCommand sqlcmd = new SqlCommand(commandstring, sqlcon);
            SqlDataReader read = sqlcmd.ExecuteReader();
            int f = 0;

            while (read.Read())
            {
                if (read[2].ToString() == t1.Text)
                {
                    t2.Text = read[0].ToString();
                    t3.Text = read[1].ToString();
                    t4.Text = read[3].ToString();
                    t5.Text = read[4].ToString();
                    t6.Text = read[5].ToString();
                    t7.Text = read[6].ToString();
                    t9.Text = read[7].ToString();
                    t10.Text = read[8].ToString();
                    t11.Text = read[9].ToString();
                    f = 1;

                }
            }

            sqlcon.Close();
            if (f == 0)
            {
                MessageBox.Show("Please ! Enter a Valid ID", "There Is no Information", MessageBoxButton.OK, MessageBoxImage.Warning, MessageBoxResult.Yes);

            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            string connectionstring = @"Data Source=DESKTOP-L8U6JI8;Initial Catalog=University_application;Integrated Security=True";
            SqlConnection sqlcon = new SqlConnection(connectionstring);

            string commandstring = "update new_instructor set Name=@pat,Dob=@pet,Email=@put,Contact=@pre,Passward=@par  where Id='" + t1.Text + "'";
            SqlCommand sqlcmd = new SqlCommand(commandstring, sqlcon);


            sqlcmd.Parameters.Add("@pat", SqlDbType.VarChar).Value = t2.Text;
            sqlcmd.Parameters.Add("@pet", SqlDbType.Date).Value = t4.Text;
            sqlcmd.Parameters.Add("@put", SqlDbType.VarChar).Value = t7.Text;
            sqlcmd.Parameters.Add("@pre", SqlDbType.VarChar).Value = t10.Text;
            sqlcmd.Parameters.Add("@par", SqlDbType.VarChar).Value = t11.Text;

            sqlcon.Open();
            int rows = sqlcmd.ExecuteNonQuery();
            sqlcon.Close();

            if (rows == 1)
                MessageBox.Show("Information Has Updated.");
            t1.Clear();
            t2.Clear();
            t3.Clear();
            t4.Clear();
            t5.Clear();
            t6.Clear();
            t7.Clear();
            t9.Clear();
            t10.Clear();
            t11.Clear();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            MessageBoxResult mr = MessageBox.Show("do you really want to Exit?", "Exit confirmation", MessageBoxButton.YesNo, MessageBoxImage.Warning, MessageBoxResult.Yes);
            switch (mr)
            {
                case MessageBoxResult.Yes:

                    break;
                case MessageBoxResult.No:
                    break;
                default:
                    break;
            }
            ins ni = new ins();
            ni.Show();
            this.Close();
        }
    }
}
