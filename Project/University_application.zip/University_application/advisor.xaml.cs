﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace University_application
{
    /// <summary>
    /// Interaction logic for advisor.xaml
    /// </summary>
    public partial class advisor : Window
    {
        public advisor()
        {
            InitializeComponent();
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult mr = MessageBox.Show("do you really want to log out?", "Log out confirmation", MessageBoxButton.YesNo, MessageBoxImage.Warning, MessageBoxResult.Yes);
            switch (mr)
            {
                case MessageBoxResult.Yes:
                    log_in ni = new log_in();
                    ni.Show();
                    this.Close();

                    break;
                case MessageBoxResult.No:
                    advisor nii = new advisor();
                    nii.Show();
                    this.Close();
                    break;
                default:
                    break;
            }
        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {
            Update_adv ni = new Update_adv();
            ni.Show();
            this.Close();
        }

        private void MenuItem_Click_2(object sender, RoutedEventArgs e)
        {
            Search_avd ni = new Search_avd();
            ni.Show();
            this.Close();
        }

        private void MenuItem_Click_3(object sender, RoutedEventArgs e)
        {
            Avd_stu ni = new Avd_stu();
            ni.Show();
            this.Close();
        }
    }
}
