﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;


namespace University_application
{
    /// <summary>
    /// Interaction logic for delete_stu.xaml
    /// </summary>
    public partial class delete_stu : Window
    {
        public delete_stu()
        {
            InitializeComponent();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
           
            t2.Clear();
            t3.Clear();
            t4.Clear();
            t6.Clear();
            t10.Clear();
            t11.Clear();
            string connectionstring = @"Data Source=DESKTOP-L8U6JI8;Initial Catalog=University_application;Integrated Security=True";
            SqlConnection sqlcon = new SqlConnection(connectionstring);
            sqlcon.Open();
            string commandstring = "select * from dbo.student_information";
            SqlCommand sqlcmd = new SqlCommand(commandstring, sqlcon);
            SqlDataReader read = sqlcmd.ExecuteReader();
            int f = 0;

            while (read.Read())
            {
                if (read[2].ToString() == t1.Text)
                {
                    t2.Text = read[0].ToString();
                    t3.Text = read[1].ToString();
                    t4.Text = read[3].ToString();
                    t6.Text = read[4].ToString();
                    t10.Text = read[5].ToString();
                    t11.Text = read[6].ToString();
                    f = 1;

                }
            }

            sqlcon.Close();
            if (f == 0)
            {
                MessageBox.Show("Please ! Enter a Valid ID", "There Is no Information", MessageBoxButton.OK, MessageBoxImage.Warning, MessageBoxResult.Yes);

            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string connectionstring = @"Data Source=DESKTOP-L8U6JI8;Initial Catalog=University_application;Integrated Security=True";
            SqlConnection sqlcon = new SqlConnection(connectionstring);

            string commandstring = "delete from dbo.student_information where Id = @a";
            SqlCommand sqlcmd = new SqlCommand(commandstring, sqlcon);
            sqlcmd.Parameters.Add("@a", SqlDbType.VarChar).Value = t1.Text;
            sqlcon.Open();
            int rows = sqlcmd.ExecuteNonQuery();
            sqlcon.Close();

            if (rows > 0)
                MessageBox.Show("Information Has Deleted.");
            t1.Clear();
            t2.Clear();
            t3.Clear();
            t4.Clear();
            t6.Clear();
            t10.Clear();
            t11.Clear();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            MessageBoxResult mr = MessageBox.Show("do you really want to Exit?", "Exit confirmation", MessageBoxButton.YesNo, MessageBoxImage.Warning, MessageBoxResult.Yes);
            switch (mr)
            {
                case MessageBoxResult.Yes:

                    break;
                case MessageBoxResult.No:
                    break;
                default:
                    break;
            }
            ins ni = new ins();
            ni.Show();
            this.Close();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            t1.Clear();
            t2.Clear();
            t3.Clear();
            t4.Clear();
            t6.Clear();
            t10.Clear();
            t11.Clear();
        }
    }
}
