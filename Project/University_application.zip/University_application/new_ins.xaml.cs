﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;

namespace University_application
{
    /// <summary>
    /// Interaction logic for new_ins.xaml
    /// </summary>
    public partial class new_ins : Window
    {
        public new_ins()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            
            MessageBoxResult mr = MessageBox.Show("do you really want to log out?", "Log out confirmation", MessageBoxButton.YesNo, MessageBoxImage.Warning, MessageBoxResult.Yes);
            switch (mr)
            {
                case MessageBoxResult.Yes:
                   
                    break;
                case MessageBoxResult.No:
                    break;
                default:
                    break;
            }
            ins ni = new ins();
            ni.Show();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {

           
            string Name = t1.Text;
            var d = (ListBoxItem)cb1.SelectedItem;     
            string Department = (string)d.Content;
            string ID =  t3.Text;
            string DOB = d1.SelectedDate.Value.ToShortDateString();
            string Contact = t4.Text;
            string JD = d2.SelectedDate.Value.ToShortDateString();
            string Gender;
            if (g1.IsChecked == true)
            {
                  Gender = "Male";
            }
            else
            {
                 Gender = "Female";
            }
            int Salary =Convert.ToInt32(t2.Text);
            string Email = t5.Text;
            int passward = Convert.ToInt32(t10.Password);
          

            string connectionstring = @"Data Source=DESKTOP-L8U6JI8;Initial Catalog=University_application;Integrated Security=True";
            SqlConnection sqlcon = new SqlConnection(connectionstring);

            SqlCommand cmd = new SqlCommand("insert into new_instructor(Name,Department,ID,DOB,JD,Gender,Email,Salary,Contact,passward) values(@a,@b,@c,@d,@e,@f,@g,@h,@i,@j)", sqlcon);
           
            cmd.Parameters.Add("@a", SqlDbType.VarChar).Value = Name;
            cmd.Parameters.Add("@b", SqlDbType.VarChar).Value = Department;
            cmd.Parameters.Add("@c", SqlDbType.VarChar).Value = ID;
            cmd.Parameters.Add("@d", SqlDbType.Date).Value = DOB;
            cmd.Parameters.Add("@e", SqlDbType.Date).Value = JD;
            cmd.Parameters.Add("@f", SqlDbType.VarChar).Value = Gender;
            cmd.Parameters.Add("@g", SqlDbType.VarChar).Value =Email;
            cmd.Parameters.Add("@h", SqlDbType.Int).Value = Salary;
            cmd.Parameters.Add("@i", SqlDbType.VarChar).Value = Contact;
            cmd.Parameters.Add("@j", SqlDbType.Int).Value = passward;
            sqlcon.Open();
            int rows = cmd.ExecuteNonQuery();
            if (rows > 0)
             
            sqlcon.Close();

            
          

            thanks_new_ins ti = new thanks_new_ins();
            ti.Show();
            this.Close();
        }
    }
}
