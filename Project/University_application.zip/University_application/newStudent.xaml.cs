﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;


namespace University_application
{
    /// <summary>
    /// Interaction logic for newStudent.xaml
    /// </summary>
    public partial class newStudent : Window
    {
        public newStudent()
        {
            InitializeComponent();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            string Name = t1.Text;
            var d = (ListBoxItem)cb3.SelectedItem;     
            string Department = (string)d.Content;
            string ID = t3.Text;
            string DOB = d1.SelectedDate.Value.ToShortDateString();
            string Contact = t2.Text;
            
            string Gender;
            if (g1.IsChecked == true)
            {
                Gender = "Male";
            }
            else
            {
                Gender = "Female";
            }
            
            string Email = t11.Text;
            int passward = Convert.ToInt32(t12.Text);
           

            string connectionstring = @"Data Source=DESKTOP-L8U6JI8;Initial Catalog=University_application;Integrated Security=True";
            SqlConnection sqlcon = new SqlConnection(connectionstring);

            SqlCommand cmd = new SqlCommand("insert into dbo.student_information(Name,Department,Id,Dob,Contact,Gender,Email,Passward) values(@a,@b,@c,@d,@e,@f,@g,@h)", sqlcon);
            
            cmd.Parameters.Add("@a", SqlDbType.VarChar).Value = Name;
            cmd.Parameters.Add("@b", SqlDbType.VarChar).Value = Department;
            cmd.Parameters.Add("@c", SqlDbType.VarChar).Value = ID;
            cmd.Parameters.Add("@d", SqlDbType.Date).Value = DOB;
            cmd.Parameters.Add("@e", SqlDbType.Int).Value = Contact;
            cmd.Parameters.Add("@f", SqlDbType.VarChar).Value = Gender;
            cmd.Parameters.Add("@g", SqlDbType.VarChar).Value = Email;
            cmd.Parameters.Add("@h", SqlDbType.Int).Value = passward;
            sqlcon.Open();
            int rows = cmd.ExecuteNonQuery();
            if (rows > 0)

                sqlcon.Close();




            Thanks_new_stu ti = new Thanks_new_stu();
            ti.Show();
            this.Close();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MessageBoxResult mr = MessageBox.Show("do you really want to log out?", "Log out confirmation", MessageBoxButton.YesNo, MessageBoxImage.Warning, MessageBoxResult.Yes);
            switch (mr)
            {
                case MessageBoxResult.Yes:

                    break;
                case MessageBoxResult.No:
                    break;
                default:
                    break;
            }
            ins ni = new ins();
            ni.Show();
            this.Close();
        }
    }
}
    

